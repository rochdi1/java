/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geographie;

import java.awt.Graphics;

/**
 *
 * @author Teilnehmer
 */
public interface Flaechig {
    
    
     public void zeichnen(Graphics g);
    
}
